﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace Automat1D
{
    class Automaton
    {

        public Cell[,] grid;
        bool[,] arr;
        float offset;
        public int iterations;
        public float cellSize;
        public int cellsInRow;
        public DoubleBufferedPanel panel;
        Pen p;
        private Bitmap buffer;
        public Graphics g;
        private object _locker = new object();
        private object _locker2 = new object();
        // Create a timer
        Random rand;
        SolidBrush brushRed, brushEmpty;




        public Automaton(DoubleBufferedPanel panel)
        {
            buffer = new Bitmap(panel.Width, panel.Height);
            this.panel = panel;
            this.panel.Paint += new PaintEventHandler(Panel_Paint);
            p = new Pen(Color.Black, 1.0f);
            brushRed = new SolidBrush(Color.Red);
            brushEmpty = new SolidBrush(SystemColors.Control);
            rand = new Random();
        }

        private void Panel_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(buffer, 0, 0);
        }

        public void CreateGrid(int size, int iterations)
        {
            grid = new Cell[iterations, size];
            arr = new bool[iterations, size];
            for (int i = 0; i < iterations; ++i)
            {
                for (int j = 0; j < size; ++j)
                {
                    grid[i, j] = new Cell(j, i);
                    arr[i, j] = new bool();
                }
            }
            cellsInRow = size;
            this.iterations = iterations;
        }

        public void RandomCells()
        {
            for (int i = 0; i < iterations; ++i)
            {
                for (int j = 0; j < cellsInRow; ++j)
                {
                    SetState(i, j, (rand.Next(2) == 0));
                }
            }
        }

        public void DrawGrid()
        {
            buffer = new Bitmap(panel.Width, panel.Height);
            g = Graphics.FromImage(buffer);
            g.Clear(panel.BackColor);
            int columns = cellsInRow;
            int rows = iterations;

            float cellSizeWidth = ((float)panel.Width) / columns;
            float cellSizeHeight = ((float)panel.Height) / rows;
            cellSize = cellSizeWidth < cellSizeHeight ? cellSizeWidth : cellSizeHeight;
            cellSize = (float)Math.Floor(cellSize);
            offset = ((panel.Width - (columns * cellSize)) / 2.0f) - 1.0f;
            offset = (float)Math.Floor(offset);

            for (int y = 0; y <= rows; ++y)
            {
                g.DrawLine(p, 0 + offset, (y * cellSize), (columns * cellSize) + offset, (y * cellSize));
            }

            for (int x = 0; x <= columns; ++x)
            {
                g.DrawLine(p, (x * cellSize) + offset, 0, (x * cellSize) + offset, (rows * cellSize));
            }

        }

        private void FillCell(Cell cell)
        {
            lock (_locker)
            {
                g.FillRectangle(cell.color == Color.Red ? brushRed : brushEmpty, (cell.Coord.X * cellSize) + offset + 1.0f, (cell.Coord.Y * cellSize) + 1.0f, cellSize - 1.0f, cellSize - 1.0f);
            } 
        }

        public void FillWithClick(int x, int y, int shape)
        {
            int coordX = (x - (int)offset) / (int)cellSize;
            int coordY = y / (int)cellSize;
            if (coordX >= 0 && coordX < cellsInRow && coordY >= 0 && coordY < iterations)
            {
                switch (shape)
                {
                    case 1:
                        SetState(coordY, coordX, !(grid[coordY, coordX].set));
                        break;
                    case 2:
                        SetState(coordY, coordX, true);
                        SetState(coordY + 1 > iterations-1 ? 0+Math.Abs(iterations - (coordY+1)) : coordY + 1, coordX, true);
                        SetState(coordY + 2 > iterations-1 ? 0+Math.Abs(iterations - (coordY+2)) : coordY + 2, coordX, true);
                        break;
                    case 3:
                        SetState(coordY, coordX, true);
                        SetState(coordY, coordX+1>cellsInRow-1? 0 + Math.Abs(iterations - (coordX + 1)) : coordX + 1, true);
                        SetState(coordY + 1 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 1)) : coordY + 1, coordX, true);
                        SetState(coordY + 1 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 1)) : coordY + 1, coordX - 1 < 0 ? cellsInRow - 1 : coordX - 1, true);
                        SetState(coordY + 2 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 2)) : coordY + 2, coordX+1>cellsInRow-1?0:coordX+1, true);
                        break;
                    case 4:
                        SetState(coordY, coordX, true);
                        SetState(coordY, coordX + 1 > cellsInRow - 1 ? 0 + Math.Abs(iterations - (coordX + 1)) : coordX + 1, true);
                        SetState(coordY + 2 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 2)) : coordY + 2, coordX, true);
                        SetState(coordY + 2 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 2)) : coordY + 2, coordX + 1 > cellsInRow - 1 ? 0 + Math.Abs(iterations - (coordX + 1)) : coordX + 1, true);
                        SetState(coordY + 1 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 1)) : coordY + 1, coordX - 1 < 0 ? cellsInRow - 1 : coordX - 1, true);
                        SetState(coordY + 1 > iterations - 1 ? 0 + Math.Abs(iterations - (coordY + 1)) : coordY + 1, coordX + 2 > cellsInRow - 1 ? 0 + Math.Abs(iterations - (coordX + 2)) : coordX + 2, true);

                        
                        break;
                }

                panel.Invalidate();
            }

        }

        private void FillCellIteration(Cell cell, int iteration)
        {
            g.FillRectangle(new SolidBrush(cell.color), (cell.Coord.X * cellSize) + offset + 1.0f, (iteration * cellSize) + 1.0f, cellSize - 1.0f, cellSize - 1.0f);
        }

        public void Run()
        {
            int aliveNeighbors;

            lock (_locker2)
            {
                for (int i = 0; i < iterations; ++i)
                {

                    for (int j = 0; j < cellsInRow; ++j)
                    {
                        arr[i, j] = grid[i, j].set;
                        aliveNeighbors = CountAliveNeighbors(grid[i, j]);
                        if (grid[i, j].set)
                        {
                            if (aliveNeighbors < 2 || aliveNeighbors > 3) arr[i, j] = false;
                        }
                        else if (aliveNeighbors == 3)
                        {
                            arr[i, j] = true;
                        }
                    }
                }

                for (int i = 0; i < iterations; ++i)
                {
                    for (int j = 0; j < cellsInRow; ++j)
                    {
                        SetState(i, j, arr[i, j]);
                    }
                }
            }
        }

        private int CountAliveNeighbors(Cell cell)
        {
            int alive = 0;

            if (grid[(cell.Coord.Y - 1) < 0 ? iterations - 1 : cell.Coord.Y - 1, (cell.Coord.X - 1) < 0 ? cellsInRow - 1 : cell.Coord.X - 1].set) alive++;  //top left
            if (grid[(cell.Coord.Y - 1) < 0 ? iterations - 1 : cell.Coord.Y - 1, cell.Coord.X].set) alive++;    //top
            if (grid[(cell.Coord.Y - 1) < 0 ? iterations - 1 : cell.Coord.Y - 1, (cell.Coord.X + 1) > cellsInRow - 1 ? 0 : cell.Coord.X + 1].set) alive++;  //top right
            if (grid[cell.Coord.Y, (cell.Coord.X - 1) < 0 ? cellsInRow - 1 : cell.Coord.X - 1].set) alive++;    //center left
            if (grid[cell.Coord.Y, (cell.Coord.X + 1) > cellsInRow - 1 ? 0 : cell.Coord.X + 1].set) alive++;    //center right
            if (grid[(cell.Coord.Y + 1) > iterations - 1 ? 0 : cell.Coord.Y + 1, (cell.Coord.X - 1) < 0 ? cellsInRow - 1 : cell.Coord.X - 1].set) alive++;  //down left
            if (grid[(cell.Coord.Y + 1) > iterations - 1 ? 0 : cell.Coord.Y + 1, cell.Coord.X].set) alive++;    //down
            if (grid[(cell.Coord.Y + 1) > iterations - 1 ? 0 : cell.Coord.Y + 1, (cell.Coord.X + 1) > cellsInRow - 1 ? 0 : cell.Coord.X + 1].set) alive++;  //down right

            return alive;
        }

        public void SetState(int iteration, int index, bool set)
        {
            lock (_locker2)
            {
                if (index < cellsInRow)
                {
                    if (set)
                    {
                        grid[iteration, index].color = Color.Red;
                        grid[iteration, index].set = true;
                    }
                    else
                    {
                        grid[iteration, index].color = SystemColors.Control;
                        grid[iteration, index].set = false;
                    }

                    FillCell(grid[iteration, index]);
                }
            }
        }

        


    }
}
