﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace Automat1D
{
    public partial class Form1 : Form
    {
        private Automaton automaton;
        private int size;
        System.Timers.Timer myTimer = new System.Timers.Timer();

        public Form1()
        {
            InitializeComponent();
            EnableDoubleBuffering();
            automaton = new Automaton(panel1);
            myTimer.Elapsed += new ElapsedEventHandler(myEvent);
            myTimer.Interval = 100;
            comboBox1.SelectedIndex = 0;
        }

        public void EnableDoubleBuffering()
        {
            this.SetStyle(ControlStyles.DoubleBuffer |
               ControlStyles.UserPaint |
               ControlStyles.AllPaintingInWmPaint,
               true);
            this.UpdateStyles();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myTimer.Enabled = false;
            size = int.Parse(textBox1.Text);
            int iterations = int.Parse(textBox2.Text);
            myTimer.Interval = int.Parse(textBox3.Text);
            automaton.CreateGrid(size, iterations);
            automaton.DrawGrid();
            label4.BackColor = Color.Red;
            //automaton.SetState(50, 50, true);
            //automaton.SetState(50, 51, true);
            //automaton.SetState(51, 50, true);
            //automaton.SetState(49, 51, true);
            //automaton.SetState(51, 52, true);
            panel1.Invalidate();
        }

        private void Step()
        {
            automaton.Run();
            //label4.BackColor = Color.Red;
            panel1.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            myTimer.Interval = int.Parse(textBox3.Text);
            myTimer.Enabled = !(myTimer.Enabled);
            if (myTimer.Enabled) label4.BackColor = Color.Green;
            else label4.BackColor = Color.Red;
        }

        private void myEvent(object source, ElapsedEventArgs e)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            Step();
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            label4.Text = elapsedMs.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            myTimer.Enabled = false;
            label4.BackColor = Color.Red;
            Step();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            automaton.RandomCells();
            myTimer.Enabled = false;
            label4.BackColor = Color.Red;
            panel1.Invalidate();
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            MouseEventArgs mouseEventArgs = e as MouseEventArgs;
            if (mouseEventArgs != null)
            {
                label5.Text = ("X= " + mouseEventArgs.X + " Y= " + mouseEventArgs.Y);
                automaton.FillWithClick(mouseEventArgs.X, mouseEventArgs.Y, comboBox1.SelectedIndex + 1);
            }
        }
    }
}
