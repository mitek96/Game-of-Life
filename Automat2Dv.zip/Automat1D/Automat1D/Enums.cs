﻿namespace Automat1D
{
    enum State
    {
        neutral,
        red,
        blue
    }
}